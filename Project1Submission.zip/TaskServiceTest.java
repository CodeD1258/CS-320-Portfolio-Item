import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService service;

    @BeforeEach
    public void setUp() {
        service = new TaskService();
    }

    @Test
    public void testAddTask() {
        service.addTask("1", "Task 1", "First Task");
        Task task = service.getTask("1");
        assertNotNull(task);
        assertEquals("Task 1", task.getName());
    }

    @Test
    public void testAddDuplicateTaskThrowsException() {
        service.addTask("2", "Task 2", "Second Task");
        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask("2", "Duplicate", "Should Fail");
        });
    }

    @Test
    public void testDeleteTask() {
        service.addTask("3", "Task 3", "To be deleted");
        service.deleteTask("3");
        assertNull(service.getTask("3"));
    }

    @Test
    public void testDeleteNonExistentTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("nonexistent");
        });
    }

    @Test
    public void testUpdateTaskName() {
        service.addTask("4", "Old Name", "Some Desc");
        service.updateTaskName("4", "New Name");
        assertEquals("New Name", service.getTask("4").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        service.addTask("5", "Task 5", "Old Desc");
        service.updateTaskDescription("5", "New Desc");
        assertEquals("New Desc", service.getTask("5").getDescription());
    }

    @Test
    public void testUpdateNonexistentTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("unknown", "Doesn't Matter");
        });
    }
}