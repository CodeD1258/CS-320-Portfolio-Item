import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("12345", "Test Task", "This is a sample task.");
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a sample task.", task.getDescription());
    }

    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Desc");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Desc");
        });
    }

    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("ID1", null, "Desc");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("ID2", "ThisNameIsWayTooLongToBeValid", "Desc");
        });
    }

    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("ID3", "Name", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("ID4", "Name", "This description is way too long to be accepted by the task object and should fail.");
        });
    }

    @Test
    public void testSetters() {
        Task task = new Task("ID5", "Initial", "Initial description");
        task.setName("Updated");
        task.setDescription("Updated description");
        assertEquals("Updated", task.getName());
        assertEquals("Updated description", task.getDescription());
    }
}