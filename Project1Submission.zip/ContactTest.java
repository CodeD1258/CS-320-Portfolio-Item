import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for Contact class.
 * Making sure we can create contacts properly and that invalid info throws errors.
 */
public class ContactTest {

    @Test
    public void testContactCreationValid() {
        // Let's create a legit contact and check that all info is stored right.
        Contact contact = new Contact("ID123", "Alice", "Jones", "1234567890", "100 Elm Street");
        assertEquals("ID123", contact.getContactId());
        assertEquals("Alice", contact.getFirstName());
        assertEquals("Jones", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("100 Elm Street", contact.getAddress());
    }

    @Test
    public void testInvalidContactId() {
        // If the contact ID is missing or too long, the constructor should throw an error.
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Bob", "Smith", "1112223333", "200 Oak Ave"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("TOO_LONG_ID_123", "Bob", "Smith", "1112223333", "200 Oak Ave"));
    }

    @Test
    public void testSettersValidation() {
        // Check that setters don't accept bad values.
        Contact contact = new Contact("ID124", "Carol", "White", "2223334444", "300 Maple Blvd");

        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("ThisIsWayTooLongName"));
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("abc123"));
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
    }
}