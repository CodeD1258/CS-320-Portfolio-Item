import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {

    private AppointmentService service;
    private Appointment appointment;

    @BeforeEach
    public void setup() {
        service = new AppointmentService();
        appointment = new Appointment("A1001", getFutureDate(2), "Eye checkup");
    }

    @Test
    public void testAddValidAppointment() {
        service.addAppointment(appointment);
        assertEquals(appointment, service.getAppointment("A1001"));
    }

    @Test
    public void testAddDuplicateIdThrowsException() {
        service.addAppointment(appointment);
        Appointment duplicate = new Appointment("A1001", getFutureDate(3), "Another one");
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(duplicate));
    }

    @Test
    public void testDeleteExistingAppointment() {
        service.addAppointment(appointment);
        service.deleteAppointment("A1001");
        assertNull(service.getAppointment("A1001"));
    }

    @Test
    public void testDeleteNonexistentAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("NONEXISTENT"));
    }

    private Date getFutureDate(int daysAhead) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, daysAhead);
        return cal.getTime();
    }
}