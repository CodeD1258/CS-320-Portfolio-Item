import java.util.HashMap;
import java.util.Map;

/**
 * This is our ContactService — think of it as the brain managing all contacts.
 * It keeps track of contacts in memory and lets you add, remove, or update them.
 */
public class ContactService {
    // We use a HashMap so we can quickly find contacts by their unique ID.
    private final Map<String, Contact> contacts = new HashMap<>();

    /**
     * Add a new contact.
     * If the ID is already taken, it throws an error — no duplicates allowed!
     */
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Oops! That contact ID already exists.");
        }
        contacts.put(contact.getContactId(), contact);
    }

    /**
     * Delete a contact by their ID.
     * If we can't find the contact, it lets you know.
     */
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Can't delete — contact not found.");
        }
        contacts.remove(contactId);
    }

    /**
     * Update the first name of a contact.
     */
    public void updateFirstName(String contactId, String firstName) {
        getContact(contactId).setFirstName(firstName);
    }

    /**
     * Update the last name of a contact.
     */
    public void updateLastName(String contactId, String lastName) {
        getContact(contactId).setLastName(lastName);
    }

    /**
     * Update the phone number of a contact.
     */
    public void updatePhone(String contactId, String phone) {
        getContact(contactId).setPhone(phone);
    }

    /**
     * Update the address of a contact.
     */
    public void updateAddress(String contactId, String address) {
        getContact(contactId).setAddress(address);
    }

    /**
     * Helper method to find a contact or throw an error if it doesn't exist.
     */
    private Contact getContact(String contactId) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found with ID: " + contactId);
        }
        return contact;
    }
}