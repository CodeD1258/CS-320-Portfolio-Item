import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for ContactService.
 * Making sure adding, deleting, and updating contacts works — and that mistakes get caught.
 */
public class ContactServiceTest {

    @Test
    public void testAddUniqueContact() {
        // Add one contact and check that adding another with the same ID fails.
        ContactService service = new ContactService();
        Contact contact = new Contact("ID001", "David", "Lee", "3334445555", "101 Birch Road");
        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () ->
            service.addContact(new Contact("ID001", "Daisy", "Lane", "4445556666", "102 Birch Road")));
    }

    @Test
    public void testDeleteContact() {
        // Add a contact, delete it, then make sure deleting again throws an error.
        ContactService service = new ContactService();
        Contact contact = new Contact("ID002", "Emma", "Hill", "5556667777", "200 Pine St");
        service.addContact(contact);
        service.deleteContact("ID002");

        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("ID002"));
    }

    @Test
    public void testUpdateContactFields() {
        // Add a contact and try updating all its fields.
        ContactService service = new ContactService();
        Contact contact = new Contact("ID003", "Frank", "Young", "6667778888", "300 Willow Way");
        service.addContact(contact);

        service.updateFirstName("ID003", "Fred");
        service.updateLastName("ID003", "Yale");
        service.updatePhone("ID003", "7778889999");
        service.updateAddress("ID003", "301 Willow Way");

        assertEquals("Fred", contact.getFirstName());
        assertEquals("Yale", contact.getLastName());
        assertEquals("7778889999", contact.getPhone());
        assertEquals("301 Willow Way", contact.getAddress());
    }

    @Test
    public void testUpdateWithInvalidData() {
        // Trying to update a contact with bad data should throw an error.
        ContactService service = new ContactService();
        Contact contact = new Contact("ID004", "Grace", "Kim", "8889990000", "400 Cedar Ct");
        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("ID004", null));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("ID004", "123"));
    }

    @Test
    public void testUpdateNonExistentContact() {
        // Trying to update a contact that isn't there? Nope, error time.
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("NOT_EXIST", "Henry"));
    }
}