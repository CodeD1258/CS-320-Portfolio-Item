import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = getFutureDate(1);
        Appointment appointment = new Appointment("12345", futureDate, "Dentist appointment");

        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Dentist appointment", appointment.getDescription());
    }

    @Test
    public void testNullIdThrowsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () ->
                new Appointment(null, getFutureDate(1), "Description"));
        assertTrue(exception.getMessage().contains("Appointment ID must be non-null"));
    }

    @Test
    public void testPastDateThrowsException() {
        Date pastDate = getFutureDate(-2);
        Exception exception = assertThrows(IllegalArgumentException.class, () ->
                new Appointment("001", pastDate, "Old date"));
        assertTrue(exception.getMessage().contains("must be in the future"));
    }

    @Test
    public void testLongDescriptionThrowsException() {
        String longDesc = "This description is way too long to be accepted by the system at all.";
        Exception exception = assertThrows(IllegalArgumentException.class, () ->
                new Appointment("001", getFutureDate(1), longDesc));
        assertTrue(exception.getMessage().contains("Description must be non-null"));
    }

    private Date getFutureDate(int daysAhead) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, daysAhead);
        return calendar.getTime();
    }
}